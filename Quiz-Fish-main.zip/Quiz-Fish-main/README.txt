Projet de fin de premier trimestre en deuxième année, fait en C++ avec la library SFML.

6 programmeurs et 4 graphistes pendant 2 semaines. 

Tout se joue au clic. 		